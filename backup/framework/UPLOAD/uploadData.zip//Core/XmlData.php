<?php
class Core_XmlData 
{
  var $name;
  var $attributes;
  var $content;
  var $children;
};